package customercontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import customer.model.Customer;
import customer.services.Customerservice;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	
	@Autowired
	private Customerservice customerservice;

	public CustomerController(Customerservice customerservice) {
		super();
		this.customerservice = customerservice;
	}
	@PostMapping("/register")
	public ResponseEntity<Customer>saveCustomer(@RequestHeader String authorization,@RequestBody Customer customer){
		return new ResponseEntity<Customer>(customerservice.saveCustomer(customer),HttpStatus.CREATED);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Customer> updateCustomer(@PathVariable("id") long id,@RequestBody Customer customer){
		return new ResponseEntity<Customer>(customerservice.UpdateCustomer(customer, id),HttpStatus.OK);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteCustomer(@PathVariable("id") long id){
		customerservice.deleteById(id);
		return new  ResponseEntity<String>("Customer deteted success",HttpStatus.OK);
	}
	
	
	

}

