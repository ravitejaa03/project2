package customer.exception;

public class CustomerNotFoundException extends RuntimeException {
	
	
	
	/**
 * 
 */
private static final long serialVersionUID = 1L;
	public CustomerNotFoundException(String string, String string2, long id) {
		super();
	}
	public CustomerNotFoundException(String msg) {
		super(msg);
	}

}

