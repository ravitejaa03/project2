package customer.dto;

public class CustomerDto {
	private long id;
	private String name;
	private String emailid;
	private long phonum;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public long getPhonum() {
		return phonum;
	}
	public void setPhonum(long phonum) {
		this.phonum = phonum;
	}
}
