package customer.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import customer.exception.CustomerNotFoundException;
import customer.model.Customer;
import customer.repository.CustomerRepository;

@Service
public class CustomerserviceImpl implements Customerservice {
	
	
	@Autowired
	CustomerRepository customerrepository;
	
	

	
	
	public CustomerserviceImpl(CustomerRepository customerrepository) {
		super();
		this.customerrepository = customerrepository;
	}
	@Override
	public Customer saveCustomer(Customer customer) {
		
		return customerrepository.save(customer);
	}
	@Override
	public  void deleteById(long id) {
		customerrepository.findById(id).orElseThrow(()-> new CustomerNotFoundException("Customer","Id",id));
		 customerrepository.deleteById(id);
	}
	@Override
	public Customer UpdateCustomer(Customer customer, long id) {
		Customer excistingCustomer=customerrepository.findById(id).orElseThrow(()-> new CustomerNotFoundException("Customer","Id",id));
		
		excistingCustomer.setName(customer.getName());
		excistingCustomer.setEmailid(customer.getEmailid());
		excistingCustomer.setPhonum(customer.getPhonum());
		   
		customerrepository.save(excistingCustomer);
		
            return excistingCustomer;
	}
}
