package customer.services;

import customer.model.Customer;

public interface Customerservice {
	

		Customer saveCustomer(Customer customer);
		 public void deleteById(long id);
		 Customer UpdateCustomer(Customer customer,long id);
	}


