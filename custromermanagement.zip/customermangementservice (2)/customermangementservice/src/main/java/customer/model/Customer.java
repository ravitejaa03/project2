package customer.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="customers")
public class Customer {
	
	
	
	private long id;
	private String name;
	private String emailid;
	private long phonum;
	
	
	
	public Customer(String name, String emailid, long phonum) {
		super();
		this.name = name;
		this.emailid = emailid;
		this.phonum = phonum;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public long getPhonum() {
		return phonum;
	}
	public void setPhonum(long phonum) {
		this.phonum = phonum;
	}

}
