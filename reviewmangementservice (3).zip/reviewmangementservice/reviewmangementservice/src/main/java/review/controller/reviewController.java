package review.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import review.model.Review;
import review.services.Reviewservice;


@RestController
@RequestMapping("/review")
public class reviewController {

	
	
	@Autowired
	private Reviewservice reviewservice;

	public reviewController(Reviewservice reviewservice) {
		super();
		this.reviewservice = reviewservice;
	}
	
	@PostMapping("/review")
	public ResponseEntity<Review>saveReview(@RequestHeader String authorization,@RequestBody Review review){
		return new ResponseEntity<Review>(reviewservice.saveReview(review),HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Review>updateReview(@PathVariable("id") long id,@RequestBody Review review){
		return new ResponseEntity<Review>(reviewservice.UpdateReview(review, id),HttpStatus.OK);
	}
	
	@GetMapping("/reviews")
	public List<Review>getReview(){
		return reviewservice.findAll();
	}
	
	
}
