package review.exception;

public class ReviewNotFoundException extends RuntimeException {
	
	
	
	/**
 * 
 */
private static final long serialVersionUID = 1L;
	public ReviewNotFoundException(String string, String string2, float rating) {
		super();
	}
	public ReviewNotFoundException(String msg) {
		super(msg);
	}

}

