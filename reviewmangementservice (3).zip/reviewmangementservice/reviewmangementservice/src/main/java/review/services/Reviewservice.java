package review.services;



import java.util.List;

import review.model.Review;

public interface Reviewservice {

	Review saveReview(Review review);
	Review UpdateReview(Review review,long id);
	List<Review> findAll();
	
}
