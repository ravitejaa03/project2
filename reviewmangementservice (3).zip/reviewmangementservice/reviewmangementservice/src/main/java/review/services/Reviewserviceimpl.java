package review.services;



import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import review.exception.ReviewNotFoundException;
import review.model.Review;
import review.repository.ReviewRepository;

@Service
public class Reviewserviceimpl implements Reviewservice {
	private static final Logger logger = LoggerFactory.getLogger(Reviewserviceimpl.class);

	@Autowired
	ReviewRepository reviewrepository;
	
	
	public Reviewserviceimpl(ReviewRepository reviewrepository) {
		super();
		this.reviewrepository = reviewrepository;
	}

	
	

	@Override
	public Review saveReview(Review review) {
		 logger.debug("In save review method,calling repo");
		return reviewrepository.save(review);
	}

	@Override
	public Review UpdateReview(Review review, long id) {
Review excistingReview=reviewrepository.findById(id).orElseThrow(()-> new ReviewNotFoundException("Review","Id",id));
		
		excistingReview.setId(review.getId());
		excistingReview.setRestaurantname(review.getRestaurantname());
		excistingReview.setRating(review.getRating());
		excistingReview.setCustomername(review.getCustomername());   
		reviewrepository.save(excistingReview);
		
            return excistingReview;
	}




	




	@Override
	public List<Review> findAll() {
		// TODO Auto-generated method stub
		return reviewrepository.findAll();
	}


}

	
	


