package com.eatza.restaurantsearch.dto;

import java.util.List;

import com.eatza.restaurantsearch.model.Restaurant;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor
public class RestaurantResponseDto {
	
	List<Restaurant> restaurants;
	int totalPages;
	long totalElements;
	
	



	public RestaurantResponseDto(List<Restaurant> restaurants, int totalPages, long totalElements) {
		super();
		this.restaurants = restaurants;
		this.totalPages = totalPages;
		this.totalElements = totalElements;
	}





	public RestaurantResponseDto() {
		// TODO Auto-generated constructor stub
	}





	public String getRestaurants() {
		// TODO Auto-generated method stub
		return null;
	}





	public void setRestaurants(List<Restaurant> asList) {
		// TODO Auto-generated method stub
		
	}





	public void setTotalElements(int i) {
		// TODO Auto-generated method stub
		
	}





	public void setTotalPages(int i) {
		// TODO Auto-generated method stub
		
	}


}
